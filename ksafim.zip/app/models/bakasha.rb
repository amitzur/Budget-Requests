class Bakasha < ActiveRecord::Base
end