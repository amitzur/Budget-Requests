class BakashaController < ActionController::Base

    def create
        puts :params
    end

end