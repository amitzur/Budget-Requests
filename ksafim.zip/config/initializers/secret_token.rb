# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Ksafim::Application.config.secret_token = 'd35cff1ac9620014ef7a94525b384d9a143ceb19869e8f53c00387940ccb1e9d504ff5a625592bec6e912cbb7818597eeb74864d088b7f9eef7ffd4cf0400acb'
